## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE----------------------------------------------------------
#  library(sleeprec)
#  features

## ----eval=FALSE----------------------------------------------------------
#  library(sleeprec)
#  feature = "amean_f"
#  
#  pretrainedClassification = applyPretrained(feature,features)

## ----eval=FALSE----------------------------------------------------------
#  library(sleeprec)
#  classification = doClassification(features)
#  result = doCV(features)

